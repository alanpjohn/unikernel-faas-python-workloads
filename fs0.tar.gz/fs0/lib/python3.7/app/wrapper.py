"""Basic FaaS input"""

import time
from app.function import handler
import json

CRLF = '\r\n'

HTTP_VERSION = 'HTTP/1.1'

def parseRequest(event:str):
    lines = event.split(CRLF)
    status_line = lines[0]
    [method, url, http_version] = status_line.split(' ')
    if http_version != HTTP_VERSION:
        raise NotImplementedError("Only HTTP/1.1 is supported")
    headers = {}
    i = 1
    while lines[i] != "" and i < len(lines):
        # print(f"{i}/{len(lines)}",lines[i])
        [key,val] = lines[i].split(": ")
        headers[key] = val
        i+=1
    if "Content-Type" in headers and headers["Content-Type"] == "application/json":
        raw_body = CRLF.join(lines[i+1:])
        print(raw_body)
        body = json.loads(raw_body)
    else:
        body = None
    return {
        "method": method,
        "body": body,
        "url" : url,
        "headers": headers,
        "params" : {}
    }   

def wrapResponse(event):
    lines = []
    lines.append("HTTP/1.1 200 OK")
    lines.append("Content-type: text/html")
    lines.append("Connection: close")
    lines.append("")
    lines.append("")
    response = CRLF.join(lines)
    response += f"""<!DOCTYPE HTML>
<html>
<head><title>It works!</title></head>
<body><h1>It works!</h1><p>{event}</p></body>
</html>\n
    """
    return response    

def handleError(exp) :
    pass

def printResponse(response) -> str:
    return response

def wrapper(event) -> str:
    """Wrapper parses http request and returns string http response"""
    try:
        event = parseRequest(event)
        print(event)
        outcome = handler(event)

        resp = wrapResponse(outcome)
    except Exception as ex:
        print(ex)
        resp = wrapResponse(ex)
    return resp

