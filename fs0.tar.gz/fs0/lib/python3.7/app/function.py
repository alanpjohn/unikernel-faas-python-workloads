"""Handler function"""

def handler(event):
    """Hello world function"""
    try:
        return event["body"]["name"]
    except Exception as ex:
        return f"Error :{ex}"

