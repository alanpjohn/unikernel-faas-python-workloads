"""Handler function"""

def handler(event):
    """Hello world function"""
    return {
        "result" : "hello world"
        }
